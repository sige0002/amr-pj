SetFactory("OpenCASCADE");
Merge "/home/sadasue/amr-pj/cad/amr07/two-story/pla-strength/SeamBeamPLA.step";
Mesh.MeshSizeMin=0.65;
Mesh.MeshSizeMax=4.0;
Mesh.MeshSizeFromCurvature=16;
Mesh.ElementOrder=2;
Mesh.HighOrderOptimize=1;
Mesh.SaveAll=1;
