Prototype only. Check supplied hardware fit, slicing orientation, strength and creep before use. Nonconductive PLA. All models fit256mm envelope.
Optional monitor hardware is NOT standard equipment.
